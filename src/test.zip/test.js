import * as React from 'react';
import validate from 'validate.js';
import { Query, Mutation } from 'react-apollo';
import { AUTHENTICATION, AUTHENTICATION_MUTATION } from './queries';

const Test = () => {
    let email, password, name = "";

    return (
        <Mutation mutation={AUTHENTICATION_MUTATION}>
            {(register, { email, password, name}) => (
                <div>
                    <form
                        onSubmit={e=>{
                            e.preventDefault();
                            register({vairables: {email, password, name}});
                            email = "";
                            password = "";
                            name = "";
                        }}
                    >
                    <input
                        onChange={e => email = e.target.value}
                    >
                    </input>
                    <input
                        onChange={e => password = e.target.value}
                    >
                    </input>
                    <input
                        onChange={e => name = e.target.value}
                    >
                    </input>
                    <button type="submit" onClick={e=>{console.log(email,password,name); console.log(typeof(email))}}>Register</button>
                    </form>
                </div>
            )}
        </Mutation>
    )
}

// (
//     <Query query={AUTHENTICATION}>
//         {({ loading, data, error }) => {
//             if (loading) return "loading"
//             if (error) return "something happened"
//             console.log(data.users)
//         }}
//     </Query>
// )


export default Test;